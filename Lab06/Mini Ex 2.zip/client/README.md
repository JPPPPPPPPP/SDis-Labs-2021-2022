# gRPC example client

The client depends on the contract module, where the protocol buffers shared between server and client are defined.
The client needs to know the interface to make remote calls.


## Instructions

To run the client:

```
python client.py
```

----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
