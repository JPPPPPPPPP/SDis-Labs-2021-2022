# gRPC example Address Book contract

This small library contains the protocol buffers (`protobuf`) of the Address Book gRPC application.

The interface is shared by the server, that implements it, and by the client, that needs it to make remote calls.


## Instructions for using Maven

To compile and install (make sure that .venv is active):

```
mvn install
mvn exec:exec
```

## Instructions for using 


## To configure the Maven project in Eclipse

'File', 'Import...', 'Maven'-'Existing Maven Projects'

'Select root directory' and 'Browse' to the project base folder.

Check that the desired POM is selected and 'Finish'.


----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
